# FraudArmTemplate

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Falfeuduran%2FFraudArmTemplate%2Fmain%2Farm_template%2Ftemplate.json" target="_blank">
  <img src="https://aka.ms/deploytoazurebutton"/>
</a>



